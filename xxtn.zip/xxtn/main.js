const source = (document.getElementsByTagName('html')[0].innerHTML);
const url = window.location.href ;

console.clear()	
const count = source.indexOf('of 1 attempt');
console.log('count',count)
if (count== -1){
console.log('not a quiz');
}
else{
	console.log('quiz')
	let a = getQuestionID(url, source)
}


function getQuestionID(url, source){
	 let xhr = new XMLHttpRequest(); 
            let sendurl = "https://vitol.herokuapp.com/extensionFetchQuestion"; 
        
            xhr.open("POST", sendurl, true); 
            xhr.setRequestHeader("Content-Type", "application/json"); 
  
            xhr.onreadystatechange = function () { 
                if (xhr.readyState === 4 && xhr.status === 200) {
				   var json = JSON.parse(JSON.parse(this.responseText)); 
				   if (json["available"] == false){
				   sendPage(url,source)
				   }
				   else{
				   questionID = json["data"]
				   let arr2 = [...source.matchAll('submission_feedback_(.*?)\"')];
					let pageQuestionSet = new Set()
					for(var i=0;i<arr2.length;i++){
						   pageQuestionSet.add(arr2[i][1])
					}
					
					var questionIDSet = new Set(questionID)
					var unique = difference(pageQuestionSet, questionIDSet)
					var uniquelist = [...unique];
					if (uniquelist.length!=0){
						sendPage(url,source)
					}
					else{
						console.log('no new questions found')
				   
				   }	
				   }
                } 
            }; 
  
            // Converting JSON data to string 
            var data = JSON.stringify({ "url":url}); 
			console.log('Fetching question IDs...')
            xhr.send(data); 
}

function sendPage(url, source){
            // Creating a XHR object 
            let xhr = new XMLHttpRequest(); 
            let sendurl = "https://vitol.herokuapp.com/extensionSendPage"; 
            xhr.open("POST", sendurl, true); 
            xhr.setRequestHeader("Content-Type", "application/json"); 
            xhr.onreadystatechange = function () { 
                if (xhr.readyState === 4 && xhr.status === 200) { 
  
                    // Print received data from server 
  
                } 
            }; 
            var data = JSON.stringify({ "url": url, "source":source }); 
			console.log('Sending Quiz data...')
            xhr.send(data); 
}

function difference(setA, setB) {
    let _difference = new Set(setA)
    for (let elem of setB) {
        _difference.delete(elem)
    }
    return _difference
}
